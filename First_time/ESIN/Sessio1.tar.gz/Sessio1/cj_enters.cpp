#include "cj_enters.hpp"

// CONSTRUCTORS 

  cj_enters::cj_enters(){

  	first = new node;
  	last = new node;
  	first->next = last;
  	first->bef = NULL;
  	last->bef = first;
  	last->next = NULL;
  	cont = 0;



 
  }

  cj_enters::cj_enters(const cj_enters &cj){
  	
  cj_enters a;
  	node* aux = cj.first->next; // Inicialitzem al principi de cj.
  	while (aux!=cj.last){
  		  		
  		a.insereix(aux->info);
  		aux=aux->next;
  	}

  	first = a.first;
  	last =a.last;
  	cont = a.cont;
  	
  	


  }

cj_enters cj_enters::operator+(const cj_enters& B) const{

	cj_enters a (*this);
	a.unir(B);
	return a;

}

  cj_enters& cj_enters::operator=(const cj_enters &cj){

  	
  	/*this->first = cj.first; UNA VERSIO
  	this->last = cj.last;
  	this->cont = cj.cont;*/

  	cj_enters a (cj);
  	this->first = a.first;
  	this->last = a.last;
  	this->cont = a.cont;



  	
}

  

  cj_enters::~cj_enters(){ // PER ACABAR
  	//cout<<"ESBORRO"<<endl;

  	node* aux = first;
  	while (aux->next!=NULL){
  		node* aux2=aux->next;
  		//delete aux;
  		aux = aux2;
  	}

  	//delete last; // PREGUNTAR BERNARDINO



  }

void cj_enters::insereix(int e){

	node* nou = new node;
	nou->info = e;

	if (cont==0){
		nou->next = last;
		nou->bef = first;
		first->next = nou;
		last->bef = nou;
		cont++;
		
	}

	else {
		nou->next = last;
		nou->bef = last->bef;
		last->bef->next = nou;
		last->bef = nou;
		cont++;
	}


}

bool cj_enters::conte(int e) const{

  	bool hi_es = false;

  	node* aux = first->next;
  	while (aux!=last and not hi_es){
  		
  		if (aux->info==e) hi_es = true;
  		else aux=aux->next;
  	}
  	return hi_es;
 }

void cj_enters::unir(const cj_enters& B){

	node* aux = B.first->next;
	while (aux!=B.last){
		if (!conte(aux->info)){
			insereix(aux->info);
			aux=aux->next;
		} 
		else aux=aux->next;
	}


} 

int cj_enters::max() const{

	int max = first->next->info;
	node* aux = first->next;
	while (aux!=last){
		if (aux->info > max) max = aux->info;
		else aux=aux->next;
	}

	

	return max;


}
int cj_enters::min() const{

	int min = first->next->info;
	node* aux = first->next;
	while (aux!=last){
		if (aux->info < min) min = aux->info;
		else aux=aux->next;
	}

	

	return min;


}

  int cj_enters::card() const{
  	return cont;
  }


bool cj_enters::operator==(const cj_enters& B) const{

  	node* aux = first->next;
  	node* aux2 = B.first->next;

  	bool are_equal = true;

  	if (this->cont==B.cont){
  		while (aux!=last and are_equal){
  			if (aux->info != aux2->info) are_equal = false;
  			else {
  				aux = aux->next;
  				aux2 = aux2->next;
  			}
  		}

  	}

  	else are_equal=false;

  	return are_equal;
  }

    bool cj_enters::operator!=(const cj_enters& B) const{

  	node* aux = first->next;
  	node* aux2 = B.first->next;

  	bool are_diff = false;

  	if (this->cont==B.cont){

  		while (aux!=last and not are_diff){
  			if (aux->info!=aux2->info) are_diff = true;
  			else {
  				aux = aux->next;
  				aux2 = aux2->next;
  			}
  		}


  	}
  	else are_diff = true;

  	return are_diff;

  }

  void cj_enters::print(ostream& os) const{
  	if (cont>0){
  		os << "[ ";
  		node* aux = first->next;
  		
  		
  		while (aux!=last){
  			
  			os << aux->info<< " ";
  			aux = aux->next;

  		}

  		os << "]";

  	}
  	os << endl;

  }


  void cj_enters::restar(const cj_enters& B){

  	node *aux = this->first->next; // Inicialitzat despres del fantasma inicial;
  	while (aux!=this->last){
  		node* aux2 = B.first->next;
  		bool hi_es = false;
  		while (aux2!=B.last and not hi_es){
  			if (aux->info==aux2->info) hi_es = true;
  			else aux2 = aux2->next;
  		}

  		if (hi_es){
  			aux->bef->next = aux->next;
  			aux->next->bef = aux->bef;
  			aux = aux->next;
  		}

  		else aux = aux->next;

  	}


  }


  cj_enters cj_enters::operator*(const cj_enters& B) const{

  	cj_enters a (*this);
	a.intersectar(B);
	return a;


  }
  

  cj_enters cj_enters::operator-(const cj_enters& B) const{

  	cj_enters a (*this);
	a.restar(B);
	return a;
  }

  void cj_enters::intersectar(const cj_enters& B){

  	node* aux = this->first->next; // Punter inicialitzat després del primer fantasma.

  	

  	while (aux!=this->last){
  		node* aux2 = B.first->next;
  		bool hi_es = false;
  		while (aux2!=B.last and not hi_es){
  			if (aux->info==aux2->info) hi_es = true; 			 
  			
  			else aux2 = aux2->next; 				
  			
  		}

  		if (!hi_es){
  			aux->bef->next = aux->next;
  			aux->next->bef = aux->bef;
  			aux = aux->next;
  		}

  		else aux = aux->next;

  		

  		
  	}

  }

 
  