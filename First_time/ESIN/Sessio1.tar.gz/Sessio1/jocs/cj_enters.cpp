#include "cj_enters.hpp"
#include <iostream>
using namespace std;

  //Constructors
  cj_enters::cj_enters(){
    ent_list = new list<int> ();

  }
  
  cj_enters::cj_enters(const cj_enters &cj){
    ent_list = cj.ent_list; // IGUAL QUE OPERADOR = ?

  }
  cj_enters::~cj_enters(){
    //delete ent_list;
  }

  cj_enters& cj_enters::operator=(const cj_enters &cj){
    delete ent_list;
    this->ent_list=cj.ent_list;
  }
  
  //Modificadors
  void cj_enters::insereix(int e)
  //Pre: Cert.
  //Post: No retorna res.
  {
    bool hi_es = conte(e);
   
    if (!hi_es){
      ent_list->insert((ent_list->end()),e);
    }


  }
  
  void cj_enters::unir(const cj_enters& B){ //Entes sense eliminar els int repetits
    
    list<int>::const_iterator it2 = B.ent_list->begin();

    while (it2!=B.ent_list->end()){

      this->ent_list->insert(ent_list->end(),(*it2));
      ++it2;

    }

  }

  void cj_enters::intersectar(const cj_enters& B){
    list<int>* def= new list <int>();
    list<int>::const_iterator it = this->ent_list->begin();

    while (it!=this->ent_list->end()){ //P.I
      list<int>::const_iterator it2 = B.ent_list->begin();
      bool hi_es = false;

      while (it2!=B.ent_list->end() and not hi_es){

        if ((*it)==(*it2)){
          
          def->insert(def->end(),(*it)); // Inserta element repetit.
          hi_es = true;
          
        }

        else ++it2;

      }

      ++it;
    }

    ent_list=def;
  }

  void cj_enters::restar(const cj_enters& B){ // Entes per eliminar d'A els elements de B.

    list<int>* def= new list <int>();
    list<int>::const_iterator it = this->ent_list->begin();

    while (it!=this->ent_list->end()){
      list<int>::const_iterator it2 = B.ent_list->begin();
      bool hi_es = false;

      while (it2!=B.ent_list->end() and not hi_es){
        if ((*it)==(*it2)) hi_es = true;
        else ++it2;
      }

    if (!hi_es) def->insert(def->end(),*(it));
    ++it;

    }

    ent_list = def;


  }

  cj_enters cj_enters::operator+(const cj_enters& B) const{ //ACABAR
    cj_enters a;
    a.ent_list = ent_list;
    a.unir(B);
    return a;

  }
  cj_enters cj_enters::operator*(const cj_enters& B) const{

    cj_enters a;
    a.ent_list = ent_list;
    a.intersectar(B);
    return a;

  }
  cj_enters cj_enters::operator-(const cj_enters& B) const{
    cj_enters a;
    a.ent_list = ent_list;
    a.restar(B);
    return a;
  }

  bool cj_enters::conte(int e) const {
    bool hi_es=false;
    list<int>::const_iterator it = ent_list->begin();
    while (it!=ent_list->end() and not hi_es){
      
      if (*(it)==e) hi_es = true;
      else ++it;
      
    }

    return hi_es;

  }

  int cj_enters::max() const{
    list<int>::const_iterator it = ent_list->begin();
    int t = (*it);
    while (it!=ent_list->end()){
      if (*(it)>t){
       t = *(it);
       ++it;
     }
      else ++it;
    }

    return t;
  }

  int cj_enters::min() const{
    list<int>::const_iterator it = ent_list->begin();
    int t = (*it);
    while (it!=ent_list->end()){
      if (*(it)<t){
       t = *(it);
       ++it;
     }
      else ++it;
    }

    return t;


  }

  int cj_enters::card() const{
    return ent_list->size();
  }
      

  bool cj_enters::operator==(const cj_enters& B) const{
    bool es_igual=true;
    if (this->ent_list->size()==B.ent_list->size()){
      list<int>::const_iterator it = this->ent_list->begin();
      list<int>::const_iterator it2 = B.ent_list->begin();
     
      while (it!=ent_list->end() and es_igual){
        if (*(it)!=*(it2)) es_igual = false;
        else {
          ++it;
          ++it2;
        }

      }

    }

    else es_igual = false;

    return es_igual;
  }
  bool cj_enters::operator!=(const cj_enters& B) const{

    return (!(this->ent_list==B.ent_list));


  }

  void cj_enters::print(ostream& os) const{

    list<int>::const_iterator it = ent_list->begin();
    os <<"[ ";
    while (it!=ent_list->end()){

      os <<*(it)<<" ";
      ++it;
    }

    os << "]"<<endl;


  }

//Tenir fet : cj_enters , inseriex, conte, print

