#include <iostream>
#include "cj_enters.hpp"
using namespace std;

int main(){

cj_enters a;

int t;
cin >> t;
while (t!=33) {
	a.insereix(t);
	cin >> t;
}


a.print(std::cout);

cj_enters b;

cin >> t;
while (t!=33){
	b.insereix(t);
	cin >> t;
}

b.print(std::cout);




cout << "PROCEDIMENT INTERSECTAR : "<<endl;
a = a * b;

a.print(std::cout);


	
}
